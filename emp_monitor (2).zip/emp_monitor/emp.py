import tkinter as tk
from tkinter import messagebox
import socket
import threading
import time
from PIL import ImageGrab, Image
import io
import struct
from datetime import datetime

class EmployeeApp:
    def __init__(self, root):  # Fixed constructor method name
        self.root = root
        self.root.title("Employee Monitoring Client")
        self.root.geometry("400x350")
        self.root.resizable(False, False)

        self.capturing = False
        self.server_ip = "192.168.1.100"  # Default HR server IP
        self.server_port = 5000

        # Login Frame
        self.login_frame = tk.Frame(root)
        self.login_frame.pack(pady=20, fill=tk.BOTH, expand=True)

        tk.Label(self.login_frame, text="Employee Monitoring System", font=("Arial", 16, "bold")).pack(pady=10)

        tk.Label(self.login_frame, text="Your Name:").pack(pady=5)
        self.name_entry = tk.Entry(self.login_frame, width=25)
        self.name_entry.pack(pady=5)

        tk.Label(self.login_frame, text="HR Server IP:").pack(pady=5)
        self.server_ip_entry = tk.Entry(self.login_frame, width=25)
        self.server_ip_entry.insert(0, self.server_ip)
        self.server_ip_entry.pack(pady=5)

        tk.Label(self.login_frame, text="HR Server Port:").pack(pady=5)
        self.server_port_entry = tk.Entry(self.login_frame, width=25)
        self.server_port_entry.insert(0, str(self.server_port))
        self.server_port_entry.pack(pady=5)

        self.start_button = tk.Button(self.login_frame, text="Start Working",
                                      command=self.start_working,
                                      bg="green", fg="white",
                                      height=2, width=15)
        self.start_button.pack(pady=10)

        # Monitoring Frame (initially hidden)
        self.monitoring_frame = tk.Frame(root)

        self.status_label = tk.Label(self.monitoring_frame,
                                     text="Screen monitoring active. Your screen is being shared with HR.",
                                     wraplength=350,
                                     fg="green",
                                     font=("Arial", 12))
        self.status_label.pack(pady=20)

        self.time_label = tk.Label(self.monitoring_frame, text="", font=("Arial", 14))
        self.time_label.pack(pady=10)

        self.end_button = tk.Button(self.monitoring_frame,
                                    text="End Work Session",
                                    command=self.end_session,
                                    bg="red",
                                    fg="white",
                                    height=2,
                                    width=20)
        self.end_button.pack(pady=20)

        # Setup clock update
        self.update_clock()

    def update_clock(self):
        """Update the clock display"""
        current_time = datetime.now().strftime("%H:%M:%S")
        self.time_label.config(text=f"Current time: {current_time}")
        self.root.after(1000, self.update_clock)

    def start_working(self):
        """Start the work session and screen monitoring"""
        name = self.name_entry.get()
        self.server_ip = self.server_ip_entry.get()

        try:
            self.server_port = int(self.server_port_entry.get())
        except ValueError:
            messagebox.showerror("Error", "Port must be a number")
            return

        if not name or not self.server_ip:
            messagebox.showerror("Error", "Name and server IP are required")
            return

        self.employee_id = name
        self.capturing = True

        self.login_frame.pack_forget()
        self.monitoring_frame.pack(pady=20, fill=tk.BOTH, expand=True)

        self.status_label.config(text=f"Hello {name}! Your screen is now being shared with HR.")

        self.capture_thread = threading.Thread(target=self.capture_screen)
        self.capture_thread.daemon = True
        self.capture_thread.start()

    def capture_screen(self):
        """Capture and stream screen to HR server"""
        client_socket = None
        try:
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.connect((self.server_ip, self.server_port))
            client_socket.send(self.employee_id.encode())

            self.root.after(0, lambda: self.status_label.config(
                text=f"Connected to HR at {self.server_ip}:{self.server_port}\nScreen sharing active",
                fg="green"))

            fps = 60
            quality = 100

            while self.capturing:
                screenshot = ImageGrab.grab()
                screenshot = screenshot.resize((1280, 720), Image.LANCZOS)

                buffer = io.BytesIO()
                screenshot.save(buffer, format="JPEG", quality=quality)
                jpg_bytes = buffer.getvalue()

                size = len(jpg_bytes)
                size_data = struct.pack("!L", size)
                client_socket.sendall(size_data + jpg_bytes)

                time.sleep(1/fps)

        except Exception as e:
            print(f"Connection error: {str(e)}")
            self.root.after(0, lambda: self.status_label.config(
                text=f"Connection error: {str(e)}\nPlease check server details and try again",
                fg="red"))
        finally:
            if client_socket:
                client_socket.close()

    def end_session(self):
        """End the monitoring session"""
        if messagebox.askyesno("Confirm", "Are you sure you want to end your work session?"):
            self.capturing = False
            time.sleep(0.5)
            messagebox.showinfo("Session Ended", "Your work session has been ended successfully.")
            self.root.destroy()

if __name__ == "__main__":  # Fixed main entry point
    root = tk.Tk()
    app = EmployeeApp(root)
    root.mainloop()
