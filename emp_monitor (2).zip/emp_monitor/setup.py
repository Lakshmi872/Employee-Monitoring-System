import os
import sys
import subprocess

def run_command(command):
    subprocess.check_call(command, shell=True)

def main():
    # Create virtual environment
    env_name = "employee_monitor_env"
    python_executable = sys.executable

    print(f"Creating virtual environment '{env_name}'...")
    run_command(f"{python_executable} -m venv {env_name}")

    # Activate virtual environment based on OS
    if sys.platform == "win32":
        activate_script = os.path.join(env_name, "Scripts", "activate")
        pip_executable = os.path.join(env_name, "Scripts", "pip")
    else:
        activate_script = f"source {env_name}/bin/activate"
        pip_executable = os.path.join(env_name, "bin", "pip")

    print("Virtual environment created successfully.")

    # Install required packages
    packages = [
        "Pillow==10.3.0",
        "opencv-python==4.9.0.80",
        "numpy==1.26.4"
    ]

    print("Installing required packages...")
    for package in packages:
        run_command(f"{pip_executable} install {package}")

    print("\nSetup complete.")
    print(f"To activate your virtual environment, run:\n\n{activate_script}\n")

if __name__ == "__main__":
    main()
