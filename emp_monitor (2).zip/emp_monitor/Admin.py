import tkinter as tk
from tkinter import ttk
import socket
import threading
import struct
import io
from PIL import Image, ImageTk
import numpy as np
import cv2
import json
import os
from datetime import datetime

class EmployeeMonitor:
    """Class to handle individual employee monitoring"""
    def __init__(self, emp_id, socket, address):
        self.emp_id = emp_id
        self.socket = socket
        self.address = address
        self.last_frame = None
        self.last_update = datetime.now()
        self.active = True

    def receive_frame(self):
        """Receive and process a single frame"""
        try:
            # Get message size (4 bytes)
            size_data = self.socket.recv(4)
            if not size_data:
                return False

            size = struct.unpack("!L", size_data)[0]

            # Receive frame data
            data = b""
            while len(data) < size:
                packet = self.socket.recv(min(size - len(data), 4096))
                if not packet:
                    return False
                data += packet

            # Convert to image
            image = Image.open(io.BytesIO(data))
            self.last_frame = image
            self.last_update = datetime.now()
            return True

        except Exception as e:
            print(f"Error receiving from {self.emp_id}: {str(e)}")
            return False

class AdminApp:
    def __init__(self, root):
        self.root = root
        self.root.title("HR Monitoring Station")
        self.root.state('zoomed')  # Maximize window

        # Server settings
        self.host = socket.gethostbyname(socket.gethostname())  # Get local IP address
        self.port = 5000

        # Employee monitors dictionary
        self.employees = {}

        # Create notebook with tabs
        self.notebook = ttk.Notebook(root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Grid View Tab
        self.grid_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.grid_frame, text="Grid View")

        # Individual View Tab
        self.individual_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.individual_frame, text="Individual View")

        # Setup grid view
        self.setup_grid_view()

        # Setup individual view
        self.setup_individual_view()

        # Status bar at the bottom to show server info
        self.status_bar = tk.Label(root, text=f"Server running at {self.host}:{self.port}", bd=1, relief=tk.SUNKEN, anchor=tk.W)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

        # Start server in background thread
        self.server_thread = threading.Thread(target=self.start_server)
        self.server_thread.daemon = True
        self.server_thread.start()

        # Start update loop
        self.update_displays()

    def setup_grid_view(self):
        """Setup the grid view layout"""
        # Create a canvas with scrollbar
        self.grid_canvas = tk.Canvas(self.grid_frame)
        scrollbar = ttk.Scrollbar(self.grid_frame, orient="vertical", command=self.grid_canvas.yview)
        self.scrollable_frame = ttk.Frame(self.grid_canvas)

        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.grid_canvas.configure(scrollregion=self.grid_canvas.bbox("all"))
        )

        self.grid_canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.grid_canvas.configure(yscrollcommand=scrollbar.set)

        self.grid_canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Grid layout will be dynamically updated as employees connect
        self.grid_labels = {}
        self.grid_frames = {}

        # Controls frame at top
        self.controls_frame = ttk.Frame(self.grid_frame)
        self.controls_frame.pack(side="top", fill="x", pady=5)

        # Show server IP and port in the controls frame
        ttk.Label(self.controls_frame, text=f"Server IP: {self.host}", font=("Arial", 12)).pack(side="left", padx=10)
        ttk.Label(self.controls_frame, text=f"Port: {self.port}", font=("Arial", 12)).pack(side="left", padx=10)
        ttk.Label(self.controls_frame, text="Active Employees: 0", font=("Arial", 12)).pack(side="left", padx=10)
        ttk.Button(self.controls_frame, text="Refresh Layout", command=self.refresh_grid).pack(side="right", padx=10)

    def setup_individual_view(self):
        """Setup the individual employee view"""
        # Server info at top
        server_info_frame = ttk.Frame(self.individual_frame)
        server_info_frame.pack(fill="x", padx=10, pady=5)
        ttk.Label(server_info_frame, text=f"Server IP: {self.host} | Port: {self.port}",
                 font=("Arial", 10)).pack(anchor="w")

        # Left side - employee list
        self.list_frame = ttk.Frame(self.individual_frame, width=200)
        self.list_frame.pack(side="left", fill="y", padx=10, pady=10)
        self.list_frame.pack_propagate(False)

        ttk.Label(self.list_frame, text="Employees", font=("Arial", 12, "bold")).pack(anchor="w", pady=5)

        # Listbox for employees
        self.employee_listbox = tk.Listbox(self.list_frame, width=25, height=20)
        self.employee_listbox.pack(fill="both", expand=True)
        self.employee_listbox.bind("<<ListboxSelect>>", self.on_employee_select)

        # Right side - employee view
        self.view_frame = ttk.Frame(self.individual_frame)
        self.view_frame.pack(side="right", fill="both", expand=True, padx=10, pady=10)

        # Employee info header
        self.emp_info_frame = ttk.Frame(self.view_frame)
        self.emp_info_frame.pack(fill="x", pady=10)

        self.emp_name_label = ttk.Label(self.emp_info_frame, text="No employee selected", font=("Arial", 14, "bold"))
        self.emp_name_label.pack(side="left")

        self.emp_status_label = ttk.Label(self.emp_info_frame, text="")
        self.emp_status_label.pack(side="right")

        # Main display
        self.display_frame = ttk.Frame(self.view_frame, relief="sunken", borderwidth=1)
        self.display_frame.pack(fill="both", expand=True)

        self.individual_display = ttk.Label(self.display_frame)
        self.individual_display.pack(fill="both", expand=True)

        # No employee selected message
        self.no_emp_label = ttk.Label(self.display_frame, text="Select an employee from the list", font=("Arial", 14))
        self.no_emp_label.place(relx=0.5, rely=0.5, anchor="center")

        # Selected employee ID
        self.selected_emp_id = None

    def refresh_grid(self):
        """Refresh the grid layout"""
        # Clear existing grid
        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()

        self.grid_labels = {}
        self.grid_frames = {}

        # Calculate grid dimensions
        num_employees = len(self.employees)
        if num_employees == 0:
            ttk.Label(self.scrollable_frame, text="No employees connected", font=("Arial", 14)).grid(row=0, column=0, padx=20, pady=20)
            return

        # Determine grid columns (2, 3, or 4 depending on count)
        if num_employees <= 4:
            cols = 2
        elif num_employees <= 9:
            cols = 3
        else:
            cols = 4

        # Create grid of employee displays
        row, col = 0, 0
        for emp_id, monitor in self.employees.items():
            # Create frame for this employee
            frame = ttk.Frame(self.scrollable_frame, relief="raised", borderwidth=2)
            frame.grid(row=row, column=col, padx=10, pady=10, sticky="nsew")

            # Employee info header
            ttk.Label(frame, text=f"ID: {emp_id}", font=("Arial", 10, "bold")).pack(anchor="w")

            # Screen display
            display = ttk.Label(frame)
            display.pack(fill="both", expand=True, padx=5, pady=5)

            # Store references
            self.grid_labels[emp_id] = display
            self.grid_frames[emp_id] = frame

            # Update grid position
            col += 1
            if col >= cols:
                col = 0
                row += 1

        # Update employee count
        for widget in self.controls_frame.winfo_children():
            if isinstance(widget, ttk.Label) and "Active Employees" in widget.cget("text"):
                widget.configure(text=f"Active Employees: {num_employees}")
                break

    def on_employee_select(self, event):
        """Handle employee selection in individual view"""
        selection = self.employee_listbox.curselection()
        if not selection:
            return

        index = selection[0]
        emp_id = self.employee_listbox.get(index)

        # Update selected employee
        self.selected_emp_id = emp_id
        self.emp_name_label.configure(text=f"Employee ID: {emp_id}")

        # Hide "no employee" message
        self.no_emp_label.place_forget()

    def update_displays(self):
        """Update all display elements"""
        # Update grid view
        for emp_id, monitor in self.employees.items():
            if monitor.last_frame and emp_id in self.grid_labels:
                # Resize for grid view
                resized = monitor.last_frame.copy()
                resized.thumbnail((320, 180))  # Smaller thumbnail for grid
                photo = ImageTk.PhotoImage(resized)

                self.grid_labels[emp_id].configure(image=photo)
                self.grid_labels[emp_id].image = photo  # Keep reference

        # Update individual view if employee selected
        if self.selected_emp_id and self.selected_emp_id in self.employees:
            monitor = self.employees[self.selected_emp_id]
            if monitor.last_frame:
                # Get window dimensions for scaling
                width = self.display_frame.winfo_width() - 20
                height = self.display_frame.winfo_height() - 20

                # Resize maintaining aspect ratio
                img_copy = monitor.last_frame.copy()
                img_copy.thumbnail((width, height))

                photo = ImageTk.PhotoImage(img_copy)
                self.individual_display.configure(image=photo)
                self.individual_display.image = photo  # Keep reference

                # Update status
                time_diff = (datetime.now() - monitor.last_update).total_seconds()
                if time_diff < 5:
                    status = "Active"
                    color = "green"
                else:
                    status = "Inactive"
                    color = "red"

                self.emp_status_label.configure(text=f"Status: {status}", foreground=color)

        # Update employee list
        current_selection = self.employee_listbox.curselection()
        selected_id = self.employee_listbox.get(current_selection[0]) if current_selection else None

        self.employee_listbox.delete(0, tk.END)
        for emp_id in self.employees.keys():
            self.employee_listbox.insert(tk.END, emp_id)

        # Restore selection if possible
        if selected_id:
            try:
                idx = list(self.employees.keys()).index(selected_id)
                self.employee_listbox.selection_set(idx)
            except ValueError:
                pass

        # Schedule next update
        self.root.after(100, self.update_displays)

    def start_server(self):
        """Start the monitoring server"""
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        # Bind to all interfaces
        server_socket.bind(('0.0.0.0', self.port))
        server_socket.listen(10)

        print(f"HR Monitoring server started on {self.host}:{self.port}")

        while True:
            try:
                # Accept new connection
                client_socket, addr = server_socket.accept()

                # Get employee ID
                emp_id = client_socket.recv(1024).decode()

                print(f"New connection from employee {emp_id} at {addr}")

                # Create new monitor for this employee
                monitor = EmployeeMonitor(emp_id, client_socket, addr)
                self.employees[emp_id] = monitor

                # Start receiving thread for this employee
                thread = threading.Thread(target=self.handle_employee, args=(monitor,))
                thread.daemon = True
                thread.start()

                # Update grid layout
                self.root.after(100, self.refresh_grid)

            except Exception as e:
                print(f"Error accepting connection: {str(e)}")

    def handle_employee(self, monitor):
        """Handle communication with an employee"""
        try:
            while monitor.active:
                # Receive and process frame
                if not monitor.receive_frame():
                    break

        except Exception as e:
            print(f"Error handling employee {monitor.emp_id}: {str(e)}")
        finally:
            # Clean up
            monitor.active = False
            monitor.socket.close()

            # Remove from employees dict
            if monitor.emp_id in self.employees:
                del self.employees[monitor.emp_id]

            # Update grid
            self.root.after(100, self.refresh_grid)
            print(f"Employee {monitor.emp_id} disconnected")

if __name__ == "__main__":
    root = tk.Tk()
    app = AdminApp(root)
    root.mainloop()
